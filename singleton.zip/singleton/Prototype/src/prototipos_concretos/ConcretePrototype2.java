package prototipos_concretos;

import prototipo.Prototype;

public class ConcretePrototype2 implements Prototype {

    private String color;
    private String precio;
    private String autonomia; //las horas que puede permanecer sin ser cargado
    private String nombre = "Audifonos";

    
    @Override
    public String getNombre(){
        return nombre;
    }
    @Override
    public String getColor() {
        return color;
    }

    @Override
    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String getPrecio() {
        return precio;
    }

    @Override
    public void setPrecio(String precio) {
        this.precio = precio;
    }

    @Override
    public String getAutonomia() {
        return autonomia;
    }

    @Override
    public void setAutonomia(String autonomia) {
        this.autonomia = autonomia;
    }
    
    
    @Override
    public Prototype clone() {
        return new ConcretePrototype2();
    }

    

    
}
