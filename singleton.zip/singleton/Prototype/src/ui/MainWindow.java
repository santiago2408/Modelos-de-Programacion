package ui;

import prototipo.Prototype;
import singleton.Singleton;
import prototipos_concretos.ConcretePrototype1;
import prototipos_concretos.ConcretePrototype2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class MainWindow extends JFrame {
    private JComboBox<String> comboBox;
    private JTextField colorField;
    private JTextField precioField;
    private JTextField autonomiaField;
    private JTextArea outputArea;
    private JScrollPane scrollPane;

    private Singleton singleton;
    private List<Prototype> clones;
    private Prototype baseAccesorio;

    public MainWindow() {
        singleton = Singleton.getInstancia();
        clones = new ArrayList<>();

        setTitle("Gestión de Accesorios");
        setSize(800, 600); // Aumentar el tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10)); // Usar BorderLayout para un mejor ajuste

        // Panel para los campos de entrada
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2, 10, 10)); // Ajustar el espaciado
        add(inputPanel, BorderLayout.NORTH);

        // Componentes del panel de entrada
        JLabel label = new JLabel("Selecciona un accesorio:");
        comboBox = new JComboBox<>(new String[]{"Fitband", "Audifonos"});
        
        JLabel colorLabel = new JLabel("Color:");
        colorField = new JTextField();

        JLabel precioLabel = new JLabel("Precio:");
        precioField = new JTextField();

        JLabel autonomiaLabel = new JLabel("Autonomía:");
        autonomiaField = new JTextField();

        JButton crearButton = new JButton("Crear Accesorio");
        JButton clonarButton = new JButton("Clonar Accesorio");

        // Añadir componentes al panel de entrada
        inputPanel.add(label);
        inputPanel.add(comboBox);
        inputPanel.add(colorLabel);
        inputPanel.add(colorField);
        inputPanel.add(precioLabel);
        inputPanel.add(precioField);
        inputPanel.add(autonomiaLabel);
        inputPanel.add(autonomiaField);
        inputPanel.add(crearButton);
        inputPanel.add(clonarButton);

        // Área de texto para mostrar la información
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 16)); // Fuente más grande
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Información de Accesorios"));

        // Añadir JScrollPane al centro de la ventana
        add(scrollPane, BorderLayout.CENTER);

        // Acción del botón Crear
        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearAccesorio();
            }
        });

        // Acción del botón Clonar
        clonarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clonarAccesorio();
            }
        });
    }

    private void crearAccesorio() {
        String seleccionado = (String) comboBox.getSelectedItem();
        singleton.crearAccesorio(seleccionado);
        
        if (seleccionado.equals("Fitband")) {
            baseAccesorio = new ConcretePrototype1();
            baseAccesorio.setAutonomia("80");
            baseAccesorio.setColor("Negro");
            baseAccesorio.setPrecio("1000");
        } else if (seleccionado.equals("Audifonos")) {
            baseAccesorio = new ConcretePrototype2();
            baseAccesorio.setAutonomia("30");
            baseAccesorio.setColor("Blanco");
            baseAccesorio.setPrecio("2000");
        }

        if (baseAccesorio != null) {
            colorField.setText(baseAccesorio.getColor());
            precioField.setText(baseAccesorio.getPrecio());
            autonomiaField.setText(baseAccesorio.getAutonomia());
        }
    }

    private void clonarAccesorio() {
        if (baseAccesorio != null) {
            // Crear un nuevo clon
            Prototype clon = baseAccesorio.clone();

            // Configurar el clon con los valores de los campos de texto si no están vacíos
            if (!colorField.getText().isEmpty()) {
                clon.setColor(colorField.getText());
            } else {
                clon.setColor(baseAccesorio.getColor());
            }
            
            if (!precioField.getText().isEmpty()) {
                clon.setPrecio(precioField.getText());
            } else {
                clon.setPrecio(baseAccesorio.getPrecio());
            }

            if (!autonomiaField.getText().isEmpty()) {
                clon.setAutonomia(autonomiaField.getText());
            } else {
                clon.setAutonomia(baseAccesorio.getAutonomia());
            }

            // Añadir el clon a la lista
            clones.add(clon);

            // Mostrar la información en el área de texto
            StringBuilder output = new StringBuilder("Accesorio Base:\n");
            output.append("Color: ").append(baseAccesorio.getColor()).append("\n");
            output.append("Precio: ").append(baseAccesorio.getPrecio()).append("\n");
            output.append("Autonomía: ").append(baseAccesorio.getAutonomia()).append("\n\n");

            output.append("=== Clones ===\n");
            for (int i = 0; i < clones.size(); i++) {
                Prototype c = clones.get(i);
                output.append("Clone ").append(i + 1).append(":\n");
                output.append("  Color: ").append(c.getColor()).append("\n");
                output.append("  Precio: ").append(c.getPrecio()).append("\n");
                output.append("  Autonomía: ").append(c.getAutonomia()).append("\n\n");
            }

            outputArea.setText(output.toString());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainWindow().setVisible(true);
            }
        });
    }
}


