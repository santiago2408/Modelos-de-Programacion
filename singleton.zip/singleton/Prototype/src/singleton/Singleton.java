/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singleton;


import prototipo.Prototype;
import prototipos_concretos.ConcretePrototype1;
import prototipos_concretos.ConcretePrototype2;
/**
 *
 * @author asant
 */
public class Singleton {
    // Variable estática que mantiene la única instancia del Singleton
    private static Singleton instancia;

    // Constructor privado para evitar la creación de instancias desde fuera
    private Singleton() {
    
    }

    // Método estático que devuelve la única instancia del Singleton
    public static Singleton getInstancia() {
        if (instancia == null) {
            instancia = new Singleton();
        }
        return instancia;
    }

    // Método ejemplo
    public Prototype crearAccesorio(String Nombre) {
        if (Nombre.equals("Fitband")){
            ConcretePrototype1 fitband = new ConcretePrototype1();
            fitband.setAutonomia("80");
            fitband.setColor("Negro");
            fitband.setPrecio("1000");
            return fitband;
        }
        
        else if (Nombre.equals("Audifonos")){
            ConcretePrototype2 sonyHeadsets = new ConcretePrototype2();
            sonyHeadsets.setAutonomia("30");
            sonyHeadsets.setColor("Blanco");
            sonyHeadsets.setPrecio("2000");
            return sonyHeadsets;
        }
        return null;
        
        
        
    }
}
