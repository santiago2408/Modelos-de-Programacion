package prototipo;

public interface Prototype {
    Prototype clone();
    public String getColor();
    public String getPrecio();
    public String getAutonomia();
    public String getNombre();
    public void setColor(String color);
    public void setPrecio(String Precio);
    public void setAutonomia(String color);
}
