package prototipo;

public interface Prototype {
    Prototype clone();
    String getType();
}
