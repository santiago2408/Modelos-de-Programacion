package cliente;

import prototipo.Prototype;

public class Client {
    private Prototype prototype;

    public Client(Prototype prototype) {
        this.prototype = prototype;
    }

    public Prototype makeCopy() {
        return prototype.clone();
    }
}

