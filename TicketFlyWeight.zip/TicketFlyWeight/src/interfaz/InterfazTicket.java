/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package interfaz;


import modelo.FabricaDeTickets;
import modelo.SistemaDeTickets;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

public class InterfazTicket extends JFrame {
    private SistemaDeTickets sistemaDeTickets;
    private JTextField txtNombrePasajero;
    private JTextField txtFechaViaje;
    private JTextField txtOrigen;
    private JTextField txtDestino;
    private JTextField txtPrecio;
    private JTextArea txtAreaTickets;
    private JTextArea txtAreaRutas;

    public InterfazTicket() {
        sistemaDeTickets = new SistemaDeTickets();

        setTitle("Sistema de Tickets de Transporte");
        setSize(600, 600); // Aumentamos el tamaño de la ventana
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Etiquetas y campos de texto para los datos del ticket
        JLabel lblNombrePasajero = new JLabel("Nombre del pasajero:");
        lblNombrePasajero.setBounds(10, 10, 150, 25);
        add(lblNombrePasajero);

        txtNombrePasajero = new JTextField();
        txtNombrePasajero.setBounds(160, 10, 200, 25);
        add(txtNombrePasajero);

        JLabel lblFechaViaje = new JLabel("Fecha de viaje:");
        lblFechaViaje.setBounds(10, 50, 150, 25);
        add(lblFechaViaje);

        txtFechaViaje = new JTextField();
        txtFechaViaje.setBounds(160, 50, 200, 25);
        add(txtFechaViaje);

        JLabel lblOrigen = new JLabel("Origen:");
        lblOrigen.setBounds(10, 90, 150, 25);
        add(lblOrigen);

        txtOrigen = new JTextField();
        txtOrigen.setBounds(160, 90, 200, 25);
        add(txtOrigen);

        JLabel lblDestino = new JLabel("Destino:");
        lblDestino.setBounds(10, 130, 150, 25);
        add(lblDestino);

        txtDestino = new JTextField();
        txtDestino.setBounds(160, 130, 200, 25);
        add(txtDestino);

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(10, 170, 150, 25);
        add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(160, 170, 200, 25);
        add(txtPrecio);

        // Botones para generar ticket y mostrar información
        JButton btnGenerarTicket = new JButton("Generar Ticket");
        btnGenerarTicket.setBounds(10, 210, 150, 25);
        add(btnGenerarTicket);

        JButton btnMostrarTickets = new JButton("Mostrar Tickets");
        btnMostrarTickets.setBounds(170, 210, 150, 25);
        add(btnMostrarTickets);

        JButton btnMostrarRutas = new JButton("Mostrar Rutas");
        btnMostrarRutas.setBounds(330, 210, 150, 25);
        add(btnMostrarRutas);

        // Áreas de texto para mostrar tickets y rutas
        txtAreaTickets = new JTextArea();
        txtAreaTickets.setBounds(10, 250, 550, 150); // Aumentamos el tamaño
        add(txtAreaTickets);

        txtAreaRutas = new JTextArea();
        txtAreaRutas.setBounds(10, 420, 550, 120); // Aumentamos el tamaño
        add(txtAreaRutas);

        // Acción para generar un ticket
        btnGenerarTicket.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombrePasajero = txtNombrePasajero.getText();
                String fechaViaje = txtFechaViaje.getText();
                String origen = txtOrigen.getText();
                String destino = txtDestino.getText();
                double precio = Double.parseDouble(txtPrecio.getText());

                sistemaDeTickets.generarTicket(nombrePasajero, fechaViaje, origen, destino, precio);

                JOptionPane.showMessageDialog(null, "Ticket generado correctamente.");
            }
        });

        // Acción para mostrar los tickets generados
        btnMostrarTickets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtAreaTickets.setText(""); // Limpiar el área de texto
                for (String ticket : sistemaDeTickets.obtenerTickets()) {
                    txtAreaTickets.append(ticket + "\n");
                }
            }
        });

        // Acción para mostrar las rutas creadas en la fábrica
        btnMostrarRutas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtAreaRutas.setText(""); // Limpiar el área de texto
                Map<String, String> rutas = FabricaDeTickets.obtenerRutas();
                for (String clave : rutas.keySet()) {
                    txtAreaRutas.append(rutas.get(clave) + "\n");
                }
            }
        });
    }

    public static void main(String[] args) {
        InterfazTicket ventana = new InterfazTicket();
        ventana.setVisible(true);
    }
}


