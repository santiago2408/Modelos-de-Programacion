/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asant
 */

public class SistemaDeTickets {
    private List<Ticket> tickets = new ArrayList<>();

    // Método para crear un nuevo ticket y agregarlo a la lista
    public void generarTicket(String nombrePasajero, String fechaViaje, String origen, String destino, double precio) {
        // Obtener la ruta desde la fábrica (Flyweight)
        Ruta ruta = FabricaDeTickets.obtenerRuta(origen, destino, precio);
        // Crear un nuevo ticket con los datos específicos (estado extrínseco)
        Ticket ticket = new Ticket(nombrePasajero, fechaViaje, ruta);
        // Agregar el ticket a la lista
        tickets.add(ticket);
    }

    // Método para obtener todos los tickets generados como texto
    public List<String> obtenerTickets() {
        List<String> resultado = new ArrayList<>();
        for (Ticket ticket : tickets) {
            resultado.add(ticket.obtenerInfoTicket());
        }
        return resultado;
    }
}


