/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author asant
 */

public class Ticket {
    private String nombrePasajero;
    private String fechaViaje;
    private Ruta ruta; // Estado intrínseco (compartido)

    public Ticket(String nombrePasajero, String fechaViaje, Ruta ruta) {
        this.nombrePasajero = nombrePasajero;
        this.fechaViaje = fechaViaje;
        this.ruta = ruta;
    }

    public String obtenerInfoTicket() {
        return "Pasajero: " + nombrePasajero + ", Fecha: " + fechaViaje + ", " + ruta.obtenerInfoRuta();
    }
}


