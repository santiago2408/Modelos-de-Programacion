/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author asant
 */

public class FabricaDeTickets {
    private static final Map<String, Ruta> rutas = new HashMap<>();

    public static Ruta obtenerRuta(String origen, String destino, double precio) {
        String clave = origen + "-" + destino;
        Ruta ruta = rutas.get(clave);

        if (ruta == null) {
            ruta = new Ruta(origen, destino, precio);
            rutas.put(clave, ruta);
        }
        return ruta;
    }

    // Método para obtener las rutas creadas en la fábrica
    public static Map<String, String> obtenerRutas() {
        Map<String, String> rutasTexto = new HashMap<>();
        for (String clave : rutas.keySet()) {
            Ruta ruta = rutas.get(clave);
            rutasTexto.put(clave, ruta.obtenerInfoRuta());
        }
        return rutasTexto;
    }
}



