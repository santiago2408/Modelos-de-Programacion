package prototipos_concretos;

import prototipo.Prototype;

public class ConcretePrototype2 implements Prototype {
    private String type = "Configuracion base de linux";

    @Override
    public Prototype clone() {
        return new ConcretePrototype2();
    }

    @Override
    public String getType() {
        return this.type;
    }
}
