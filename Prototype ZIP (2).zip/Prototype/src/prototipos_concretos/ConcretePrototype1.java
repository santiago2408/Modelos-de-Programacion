package prototipos_concretos;

import prototipo.Prototype;

public class ConcretePrototype1 implements Prototype {
    private String type = "Configuración base de windows";

    @Override
    public Prototype clone() {
        return new ConcretePrototype1();
    }

    @Override
    public String getType() {
        return this.type;
    }
}
