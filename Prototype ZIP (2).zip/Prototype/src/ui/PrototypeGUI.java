package ui;

import cliente.Client;
import prototipo.Prototype;
import prototipos_concretos.ConcretePrototype1;
import prototipos_concretos.ConcretePrototype2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrototypeGUI extends JFrame {
    private JComboBox<String> prototypeSelector;
    private JTextField resultField;

    public PrototypeGUI() {
        setTitle("Prototype Pattern Example");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel label = new JLabel("Seleccione que sistema operativo quiere instalar");
        label.setBounds(10, 10, 600, 20);
        add(label);

        prototypeSelector = new JComboBox<>(new String[]{"OS Windows", "OS Linux"});
        prototypeSelector.setBounds(50, 40, 150, 20);
        add(prototypeSelector);

        JButton cloneButton = new JButton("Clone");
        cloneButton.setBounds(10, 70, 260, 30);
        add(cloneButton);

        resultField = new JTextField();
        resultField.setBounds(10, 80, 260, 20);
        resultField.setEditable(false);
        add(resultField);

        cloneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Prototype prototype = null;
                String selected = (String) prototypeSelector.getSelectedItem();
                
                if (selected.equals("OS Windows")) {
                    prototype = new ConcretePrototype1();
                } else if (selected.equals("OS Linux")) {
                    prototype = new ConcretePrototype2();
                }

                if (prototype != null) {
                    Client client = new Client(prototype);
                    Prototype cloned = client.makeCopy();
                    resultField.setText("Clonado: " + cloned.getType());
                }
            }
        });
    }

    public static void main(String[] args) {
        PrototypeGUI gui = new PrototypeGUI();
        gui.setVisible(true);
    }
}
